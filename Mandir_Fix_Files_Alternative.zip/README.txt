HAZRA BARI SQL CONFLICT FIX

Fixes the duplicate ON CONFLICT clause in _pg_sql().

1. Back up the current GitHub app.py first.
2. Replace app.py in the repository root with this app.py. Keep requirements.txt beside it.
3. Commit both files to the main branch.
4. Reboot the Streamlit app.

This patch does not drop, clear, or reset any database tables or user data. Keep your existing Streamlit Secrets / DATABASE_URL unchanged.
